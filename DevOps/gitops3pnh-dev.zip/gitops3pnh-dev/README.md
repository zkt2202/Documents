# sample: Helm charts - deploy to k8s 

1. Input namespace, Database and othes infor in /app_chart/values.yaml
2. Update ImagePullSecret in file pullsecret.txt
3. Check .HelmIgnore file:   cat app_chart/.helmignore
4. Run bash script: sh prod_deploy.sh -f ./app_chart/values.yaml -t latest
 
